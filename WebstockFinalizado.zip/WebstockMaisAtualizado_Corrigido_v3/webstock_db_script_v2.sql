-- Script SQL Atualizado para WebStock com Sistema de Permissões e Feedbacks
-- Versão 2.0 - Inclui roles (administrador/estudante) e sistema de feedbacks

-- 1. Criação do Banco de Dados
CREATE DATABASE IF NOT EXISTS webstock_db
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

-- Seleciona o banco de dados para uso
USE webstock_db;

-- 2. Tabela de Usuários (com sistema de roles)
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    senha_hash VARCHAR(255) NOT NULL,
    nome VARCHAR(100),
    role ENUM('administrador', 'estudante') NOT NULL DEFAULT 'estudante',
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ativo BOOLEAN DEFAULT TRUE,
    INDEX idx_email (email),
    INDEX idx_role (role)
);

-- 3. Tabela de Itens em Estoque
CREATE TABLE IF NOT EXISTS itens_estoque (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    status ENUM('Ativo', 'Inativo') NOT NULL DEFAULT 'Ativo',
    quantidade INT NOT NULL DEFAULT 0,
    data_registro DATE,
    materia VARCHAR(100),
    observacao TEXT,
    usuario_id INT,
    data_modificacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL,
    INDEX idx_status (status),
    INDEX idx_nome (nome)
);

-- 4. Tabela de Feedbacks
CREATE TABLE IF NOT EXISTS feedbacks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    titulo VARCHAR(200) NOT NULL,
    mensagem TEXT NOT NULL,
    categoria ENUM('sugestao', 'problema', 'duvida', 'outro') NOT NULL DEFAULT 'outro',
    status ENUM('pendente', 'lido', 'resolvido') NOT NULL DEFAULT 'pendente',
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_leitura TIMESTAMP NULL,
    arquivado BOOLEAN DEFAULT FALSE,
    
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_status (status),
    INDEX idx_usuario (usuario_id),
    INDEX idx_data (data_criacao)
);

-- 5. Tabela de Notificações
CREATE TABLE IF NOT EXISTS notificacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_destinatario_id INT NOT NULL,
    tipo ENUM('feedback', 'sistema', 'estoque') NOT NULL,
    titulo VARCHAR(200) NOT NULL,
    mensagem TEXT NOT NULL,
    lida BOOLEAN DEFAULT FALSE,
    referencia_id INT NULL, -- ID do feedback ou outro item relacionado
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (usuario_destinatario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    INDEX idx_destinatario (usuario_destinatario_id),
    INDEX idx_lida (lida),
    INDEX idx_tipo (tipo)
);

-- 6. Dados de Exemplo

-- Inserir usuários de exemplo (administrador e estudante)
-- Nota: As senhas devem ser hasheadas com bcrypt na aplicação real
INSERT INTO usuarios (email, senha_hash, nome, role) VALUES
('admin@webstock.com', '$2b$10$placeholder_hash_admin', 'Administrador WebStock', 'administrador'),
('estudante@webstock.com', '$2b$10$placeholder_hash_estudante', 'Estudante Teste', 'estudante');

-- Inserir dados de estoque de exemplo
INSERT INTO itens_estoque (nome, status, quantidade, data_registro, materia, observacao, usuario_id) VALUES
('Notebook', 'Ativo', 200, '2025-06-07', 'Curso Dev', 'Formatar a máquina 17', 1),
('Mouse', 'Inativo', 30, '2025-04-30', 'Curso Dev', 'Manutenção Necessária', 1),
('Caderno', 'Ativo', 410, '2024-11-19', 'Regular', 'Necessita de Reposição', 1),
('Mochila', 'Inativo', 270, '2025-06-02', '-', '-', 1),
('Régua', 'Inativo', 130, '2025-05-04', 'Regular', 'Necessita de Reposição', 1),
('Caneta', 'Ativo', 110, '2025-02-12', 'Regular', '-', 1),
('Lápis', 'Ativo', 0, '2025-03-29', 'Regular', '-', 1);

-- Inserir feedbacks de exemplo
INSERT INTO feedbacks (usuario_id, titulo, mensagem, categoria, status) VALUES
(2, 'Sugestão de melhoria', 'Seria interessante adicionar filtros na página de categorias', 'sugestao', 'pendente'),
(2, 'Problema no login', 'Tive dificuldade para fazer login ontem', 'problema', 'lido');

-- Inserir notificações de exemplo para o administrador
INSERT INTO notificacoes (usuario_destinatario_id, tipo, titulo, mensagem, referencia_id) VALUES
(1, 'feedback', 'Novo feedback recebido', 'Estudante Teste enviou: Sugestão de melhoria', 1),
(1, 'feedback', 'Novo feedback recebido', 'Estudante Teste enviou: Problema no login', 2);