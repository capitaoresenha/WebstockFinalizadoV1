// Sistema de Feedbacks - WebStock
// Versão 1.0 - Integrado com notificações

// const API_URL = 'http://localhost:3000/api'; // Removido para evitar SyntaxError, já declarado em notificacoes.js

// Recuperar dados do usuário logado
function getUsuarioLogado() {
    const usuario = localStorage.getItem('usuarioLogado');
    return usuario ? JSON.parse(usuario) : null;
}

// Verificar se o usuário é administrador
function isAdministrador() {
    const usuario = getUsuarioLogado();
    return usuario && usuario.role === 'administrador';
}

/**
 * Carregar feedbacks do banco de dados
 */
async function carregarFeedbacks() {
    const usuario = getUsuarioLogado();
    
    if (!usuario) {
        document.getElementById('feedbacks-container').innerHTML = `
            <p style="text-align: center; padding: 20px; color: #f44336;">
                Você precisa estar logado para ver os feedbacks.
            </p>
        `;
        return;
    }

    try {
        const response = await fetch(`${API_URL}/feedbacks?usuarioId=${usuario.usuarioId}`);
        
        if (!response.ok) {
            // Se a resposta não for OK, tentamos ler o JSON para ver se há uma mensagem de erro do servidor
            let erroMensagem = `Erro HTTP: ${response.status}`;
            try {
                const errorData = await response.json();
                erroMensagem = errorData.erro || erroMensagem;
            } catch (e) {
                // Ignora erro ao tentar ler JSON se a resposta não for JSON
            }
            throw new Error(erroMensagem);
        }

        const data = await response.json();

        if (data.sucesso && data.feedbacks) {
            renderizarFeedbacks(data.feedbacks);
        } else {
            // Se a resposta for OK, mas o formato for inválido (sem sucesso ou feedbacks), ainda é um erro
            throw new Error('Formato de resposta inválido ou falha na API');
        }

    } catch (error) {
        console.error('Erro ao carregar feedbacks:', error);
        document.getElementById('feedbacks-container').innerHTML = `
            <p style="text-align: center; padding: 20px; color: #f44336;">
                Erro ao carregar feedbacks: ${error.message}. Verifique se o servidor está rodando e se o usuário tem permissão.
            </p>
        `;
    }
}

/**
 * Renderizar feedbacks na página
 */
function renderizarFeedbacks(feedbacks) {
    const container = document.getElementById('feedbacks-container');
    const isAdmin = isAdministrador();

    if (!feedbacks || feedbacks.length === 0) {
        container.innerHTML = `
            <p style="text-align: center; padding: 20px; color: #666;">
                Nenhum feedback encontrado.
            </p>
        `;
        return;
    }

    container.innerHTML = '';

    feedbacks.forEach(feedback => {
        const card = document.createElement('div');
        card.className = 'feedback-card';

        // Informações do usuário (apenas para administradores)
        const infoUsuario = isAdmin && feedback.nome_usuario ? `
            <div class="feedback-footer">
                <span class="feedback-usuario">👤 ${feedback.nome_usuario} (${feedback.email_usuario})</span>
                <span class="feedback-data">📅 ${feedback.data_criacao}</span>
            </div>
        ` : `
            <div class="feedback-footer">
                <span class="feedback-data">📅 ${feedback.data_criacao}</span>
            </div>
        `;

        // Botões de ação (apenas para administradores)
        const acoesHTML = isAdmin ? `
            <div class="feedback-acoes">
                ${feedback.status !== 'lido' ? `<button class="btn-status lido" onclick="atualizarStatusFeedback(${feedback.id}, 'lido')">Marcar como Lido</button>` : ''}
                ${feedback.status !== 'resolvido' ? `<button class="btn-status resolvido" onclick="atualizarStatusFeedback(${feedback.id}, 'resolvido')">Marcar como Resolvido</button>` : ''}
            </div>
        ` : '';

        card.innerHTML = `
            <div class="feedback-header">
                <h3 class="feedback-titulo">${feedback.titulo}</h3>
                <div class="feedback-meta">
                    <span class="feedback-categoria ${feedback.categoria}">${formatarCategoria(feedback.categoria)}</span>
                    <span class="feedback-status ${feedback.status}">${formatarStatus(feedback.status)}</span>
                </div>
            </div>
            <p class="feedback-mensagem">${feedback.mensagem}</p>
            ${infoUsuario}
            ${acoesHTML}
        `;

        container.appendChild(card);
    });
}

/**
 * Formatar categoria para exibição
 */
function formatarCategoria(categoria) {
    const categorias = {
        'sugestao': '💡 Sugestão',
        'problema': '⚠️ Problema',
        'duvida': '❓ Dúvida',
        'outro': '📝 Outro'
    };
    return categorias[categoria] || categoria;
}

/**
 * Formatar status para exibição
 */
function formatarStatus(status) {
    const statuses = {
        'pendente': '⏳ Pendente',
        'lido': '👁️ Lido',
        'resolvido': '✅ Resolvido'
    };
    return statuses[status] || status;
}

/**
 * Enviar novo feedback
 */
async function enviarFeedback(event) {
    event.preventDefault();

    const usuario = getUsuarioLogado();
    
    if (!usuario) {
        mostrarMensagem('Você precisa estar logado para enviar feedback.', 'error');
        return;
    }

    const titulo = document.getElementById('titulo').value.trim();
    const mensagem = document.getElementById('mensagem').value.trim();
    const categoria = document.getElementById('categoria').value;

    if (!titulo || !mensagem) {
        mostrarMensagem('Por favor, preencha todos os campos obrigatórios.', 'error');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/feedbacks`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                usuarioId: usuario.usuarioId,
                titulo,
                mensagem,
                categoria
            })
        });

	        const data = await response.json();
	
	        if (response.ok && data.sucesso) {
            mostrarMensagem('Feedback enviado com sucesso! Os administradores foram notificados.', 'success');
            document.getElementById('feedback-form').reset();
            
            // Recarregar lista de feedbacks após 2 segundos
            setTimeout(() => {
                carregarFeedbacks();
            }, 2000);
        } else {
            mostrarMensagem('Erro ao enviar feedback: ' + data.erro, 'error');
        }

    } catch (error) {
        console.error('Erro ao enviar feedback:', error);
        mostrarMensagem('Erro ao comunicar com o servidor. Verifique sua conexão.', 'error');
    }
}

/**
 * Atualizar status do feedback (apenas administradores)
 */
async function atualizarStatusFeedback(feedbackId, novoStatus) {
    const usuario = getUsuarioLogado();
    
    if (!usuario || usuario.role !== 'administrador') {
        alert('Acesso negado. Apenas administradores podem atualizar feedbacks.');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/feedbacks/${feedbackId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                usuarioId: usuario.usuarioId,
                status: novoStatus
            })
        });

        const data = await response.json();

        if (response.ok) {
            // Recarregar feedbacks
            carregarFeedbacks();
        } else {
            alert('Erro ao atualizar feedback: ' + data.erro);
        }

    } catch (error) {
        console.error('Erro ao atualizar feedback:', error);
        alert('Erro ao comunicar com o servidor.');
    }
}

/**
 * Mostrar mensagem de sucesso ou erro
 */
function mostrarMensagem(texto, tipo) {
    const messageDiv = document.getElementById('feedback-message');
    messageDiv.textContent = texto;
    messageDiv.className = 'feedback-message ' + tipo;
    messageDiv.style.display = 'block';

    // Esconder mensagem após 5 segundos
    setTimeout(() => {
        messageDiv.style.display = 'none';
    }, 5000);
}

// Inicialização quando a página carrega
document.addEventListener('DOMContentLoaded', () => {
    // Verificar se o usuário está logado
    const usuario = getUsuarioLogado();
    
    if (!usuario) {
        // Redirecionar para login se não estiver logado
        alert('Você precisa estar logado para acessar esta página.');
        window.location.href = 'login.html';
        return;
    }

    // Carregar feedbacks
    carregarFeedbacks();

    // Adicionar event listener ao formulário
    const form = document.getElementById('feedback-form');
    if (form) {
        form.addEventListener('submit', enviarFeedback);
    }
});
