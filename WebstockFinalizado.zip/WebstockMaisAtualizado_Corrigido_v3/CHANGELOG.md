# Changelog - WebStock v2.0

## 🎉 Versão 2.0 - Sistema de Permissões e Feedbacks

**Data**: Novembro 2025

---

## ✨ Novas Funcionalidades

### 1. Sistema de Permissões (Roles)
- ✅ Implementado sistema de distinção entre **Administrador** e **Estudante**
- ✅ Administradores podem editar categorias
- ✅ Estudantes têm acesso apenas de visualização
- ✅ Verificação de permissões no backend e frontend

### 2. Edição de Categorias (Administradores)
- ✅ Botão **Editar** (✏️) em cada item da tabela
- ✅ Botão **Deletar** (🗑️) em cada item da tabela
- ✅ Botão **Adicionar Item** (➕) no final da página
- ✅ Interface de edição via prompts nativos
- ✅ Validação de permissões antes de cada ação

### 3. Sistema de Feedbacks
- ✅ Nova página **feedbacks.html** com design consistente
- ✅ Formulário de envio de feedbacks (todos os usuários)
- ✅ Categorização: Sugestão, Problema, Dúvida, Outro
- ✅ Sistema de status: Pendente, Lido, Resolvido
- ✅ Administradores veem todos os feedbacks
- ✅ Estudantes veem apenas seus próprios feedbacks
- ✅ Botões de ação para administradores alterarem status

### 4. Sistema de Notificações
- ✅ **Contador visual** no sino de notificações
- ✅ Badge vermelho mostrando quantidade de notificações não lidas
- ✅ Caixa de notificações com lista completa
- ✅ Integração automática com feedbacks
- ✅ Notificações em tempo real para administradores
- ✅ Atualização automática a cada 30 segundos
- ✅ Botão "Marcar todas como lidas"
- ✅ Indicador visual para notificações não lidas

### 5. Melhorias na Interface
- ✅ Link para **Feedbacks** adicionado em todas as páginas
- ✅ Estilos consistentes com a paleta de cores original
- ✅ Animações e transições suaves
- ✅ Design responsivo mantido

---

## 🗄️ Alterações no Banco de Dados

### Tabelas Modificadas
- **usuarios**: Adicionada coluna `role` (administrador/estudante)

### Novas Tabelas
- **feedbacks**: Armazena feedbacks dos usuários
- **notificacoes**: Sistema de notificações

### Novo Script SQL
- `webstock_db_script_v2.sql`: Script completo com todas as tabelas

---

## 📁 Arquivos Criados

### HTML
- `html/feedbacks.html` - Página de feedbacks

### CSS
- `css/feedbacks.css` - Estilos da página de feedbacks

### JavaScript
- `js/feedbacks.js` - Lógica de feedbacks
- `js/notificacoes.js` - Sistema de notificações

### Documentação
- `README_SISTEMA_PERMISSOES.md` - Guia completo do sistema
- `CHANGELOG.md` - Este arquivo
- `webstock_db_script_v2.sql` - Script SQL atualizado

---

## 🔧 Arquivos Modificados

### Backend
- `webstock_backend/server.js`:
  - Novas rotas para feedbacks
  - Novas rotas para notificações
  - Verificação de permissões em todas as rotas de edição
  - Retorno do role no login

### Frontend - JavaScript
- `js/categorias.js`:
  - Funções de edição, adição e deleção
  - Verificação de role do usuário
  - Renderização condicional de botões de ação
  
- `js/confirmacao.js`:
  - Armazenamento do role no localStorage
  - Salvamento completo dos dados do usuário

### Frontend - HTML
- `html/home.html`:
  - Contador de notificações no sino
  - Link para página de feedbacks
  - Estrutura da caixa de notificações
  
- `html/categorias.html`:
  - Contador de notificações no sino
  - Link para página de feedbacks
  - Estrutura da caixa de notificações

### Frontend - CSS
- `css/categorias.css`:
  - Estilos para botões de edição e deleção
  - Estilos para botão de adicionar
  
- `css/home.css`:
  - Estilos do contador de notificações
  - Estilos da caixa de notificações
  - Estilos dos itens de notificação

---

## 🔐 Melhorias de Segurança

- ✅ Validação de permissões no backend para todas as operações
- ✅ Verificação de role antes de exibir botões de ação
- ✅ Proteção contra acesso não autorizado às rotas de edição
- ✅ Mensagens de erro apropriadas para tentativas não autorizadas

---

## 📊 Endpoints da API Adicionados

### Feedbacks
- `POST /api/feedbacks` - Criar feedback
- `GET /api/feedbacks?usuarioId={id}` - Listar feedbacks (filtrado por role)
- `PUT /api/feedbacks/:id` - Atualizar status (admin only)

### Notificações
- `GET /api/notificacoes?usuarioId={id}` - Listar notificações
- `GET /api/notificacoes/count?usuarioId={id}` - Contar não lidas
- `PUT /api/notificacoes/:id/marcar-lida` - Marcar como lida
- `PUT /api/notificacoes/marcar-todas-lidas` - Marcar todas como lidas

### Categorias (Atualizados)
- `POST /api/categorias` - Adicionar item (admin only)
- `PUT /api/categorias/:id` - Editar item (admin only)
- `DELETE /api/categorias/:id` - Deletar item (admin only)

---

## 🎨 Design e UX

### Paleta de Cores Mantida
- Azul Principal: `#4547B5`
- Amarelo/Dourado: `#FFB41F`
- Branco: `#F5F6FF`
- Verde (Status Ativo): `#4caf50`
- Vermelho (Notificações): `#f44336`

### Elementos Visuais
- ✅ Gradientes consistentes em todas as páginas
- ✅ Sombras e bordas arredondadas
- ✅ Animações de hover suaves
- ✅ Ícones emoji para melhor visualização
- ✅ Badge de notificação destacado

---

## 🚀 Como Atualizar

1. **Backup do banco de dados atual**
2. **Execute o novo script SQL**: `webstock_db_script_v2.sql`
3. **Substitua os arquivos do projeto** pelos novos
4. **Reinicie o servidor backend**
5. **Atualize usuários existentes** com role apropriado:
   ```sql
   UPDATE usuarios SET role = 'administrador' WHERE email = 'seu_admin@email.com';
   ```

---

## 📝 Notas de Migração

### Para Usuários Existentes
- Todos os usuários existentes terão role `estudante` por padrão
- Administradores devem ser configurados manualmente no banco de dados

### Compatibilidade
- ✅ Mantém compatibilidade com funcionalidades anteriores
- ✅ Não quebra o sistema de login existente
- ✅ Categorias antigas continuam funcionando normalmente

---

## 🐛 Correções de Bugs

- Nenhum bug corrigido (nova funcionalidade)

---

## 📚 Documentação

- ✅ README completo com instruções de instalação
- ✅ Documentação de endpoints da API
- ✅ Guia de uso para administradores e estudantes
- ✅ Exemplos de queries SQL

---

## 🔮 Próximas Versões (Planejado)

- [ ] Interface visual para edição de categorias (modal/formulário)
- [ ] Sistema de busca e filtros na página de feedbacks
- [ ] Notificações push em tempo real (WebSockets)
- [ ] Dashboard de estatísticas para administradores
- [ ] Exportação de feedbacks em PDF/Excel
- [ ] Sistema de anexos em feedbacks

---

## 👥 Créditos

**Desenvolvido para**: WebStock - Sistema de Gerenciamento de Estoque  
**Versão**: 2.0  
**Data**: Novembro 2025

---

## 📞 Suporte

Para dúvidas ou problemas:
1. Consulte o `README_SISTEMA_PERMISSOES.md`
2. Verifique a seção de "Solução de Problemas"
3. Entre em contato com a equipe de desenvolvimento

---

**Fim do Changelog v2.0**
