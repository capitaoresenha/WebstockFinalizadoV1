# 🚀 Guia Rápido - WebStock v2.0

## Início Rápido em 5 Passos

### 1️⃣ Configurar o Banco de Dados

```bash
# Criar o banco de dados
mysql -u root -p

# Executar o script SQL
mysql -u root -p < webstock_db_script_v2.sql
```

---

### 2️⃣ Configurar o Backend

```bash
# Navegar para a pasta do backend
cd webstock_backend

# Instalar dependências
npm install

# Editar credenciais do banco (db.js)
nano db.js
# Altere: host, user, password, database

# Iniciar o servidor
node server.js
```

✅ **Servidor rodando em**: `http://localhost:3000`

---

### 3️⃣ Criar Primeiro Administrador

```sql
# Cadastre-se normalmente pelo site, depois:
UPDATE usuarios SET role = 'administrador' WHERE email = 'seu_email@exemplo.com';
```

---

### 4️⃣ Abrir o Frontend

```bash
# Opção 1: Abrir diretamente
# Abra html/index.html no navegador

# Opção 2: Usar servidor local
python3 -m http.server 8080
# Acesse: http://localhost:8080/html/index.html
```

---

### 5️⃣ Testar as Funcionalidades

**Como Administrador:**
1. Login → Categorias → Clique em ✏️ ou 🗑️
2. Categorias → Clique em "➕ Adicionar Item"
3. Feedbacks → Veja todos os feedbacks
4. Sino → Veja notificações de novos feedbacks

**Como Estudante:**
1. Login → Categorias → Apenas visualização
2. Feedbacks → Envie um feedback
3. Sino → Veja suas notificações

---

## 🎯 Funcionalidades Principais

| Funcionalidade | Administrador | Estudante |
|----------------|---------------|-----------|
| Ver Categorias | ✅ | ✅ |
| Editar Categorias | ✅ | ❌ |
| Enviar Feedbacks | ✅ | ✅ |
| Ver Todos Feedbacks | ✅ | ❌ (apenas próprios) |
| Alterar Status Feedbacks | ✅ | ❌ |
| Receber Notificações | ✅ | ✅ |

---

## 🔑 Credenciais de Teste

Após executar o script SQL v2, você terá:

**Administrador:**
- Email: `admin@webstock.com`
- Senha: *Você precisa definir via bcrypt*

**Estudante:**
- Email: `estudante@webstock.com`
- Senha: *Você precisa definir via bcrypt*

> **Nota**: As senhas no script são placeholders. Cadastre-se normalmente pelo site.

---

## 📱 Navegação Rápida

- **Início**: `home.html`
- **Categorias**: `categorias.html`
- **Feedbacks**: `feedbacks.html`
- **Login**: `login.html`
- **Cadastro**: `cadastro.html`

---

## 🐛 Problemas Comuns

### Erro: "Erro ao carregar dados"
**Solução**: Verifique se o servidor backend está rodando em `http://localhost:3000`

### Botões de edição não aparecem
**Solução**: Confirme que o usuário tem `role = 'administrador'` no banco de dados

### Contador de notificações não aparece
**Solução**: Verifique o console do navegador (F12) para erros de JavaScript

---

## 📞 Ajuda

- **README Completo**: `README_SISTEMA_PERMISSOES.md`
- **Changelog**: `CHANGELOG.md`
- **Documentação API**: Veja seção "Endpoints da API" no README

---

**Pronto para começar! 🎉**
