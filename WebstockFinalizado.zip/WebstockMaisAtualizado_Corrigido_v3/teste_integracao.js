// Script de Teste da Integração SQL - Categorias
// Execute com: node teste_integracao.js

const http = require('http');

const API_URL = 'http://localhost:3000/api/categorias';

console.log('🧪 Iniciando teste de integração...\n');

// Teste 1: Verificar se o endpoint responde
console.log('📡 Teste 1: Verificando endpoint GET /api/categorias');

http.get(API_URL, (res) => {
    let data = '';

    res.on('data', (chunk) => {
        data += chunk;
    });

    res.on('end', () => {
        try {
            const response = JSON.parse(data);
            
            console.log(`✅ Status Code: ${res.statusCode}`);
            console.log(`✅ Content-Type: ${res.headers['content-type']}`);
            
            if (response.sucesso && response.itens) {
                console.log(`✅ Resposta válida recebida`);
                console.log(`✅ Total de itens: ${response.itens.length}`);
                
                console.log('\n📊 Itens encontrados:');
                response.itens.forEach((item, index) => {
                    console.log(`\n   ${index + 1}. ${item.nome}`);
                    console.log(`      ID: ${item.id}`);
                    console.log(`      Status: ${item.status}`);
                    console.log(`      Quantidade: ${item.quantidade}`);
                    console.log(`      Data: ${item.data_registro}`);
                    console.log(`      Matéria: ${item.materia}`);
                    console.log(`      Observação: ${item.observacao}`);
                });
                
                console.log('\n✅ TESTE PASSOU! Integração funcionando corretamente.');
            } else {
                console.log('❌ TESTE FALHOU: Formato de resposta inválido');
                console.log('Resposta recebida:', response);
            }
            
        } catch (error) {
            console.log('❌ TESTE FALHOU: Erro ao parsear JSON');
            console.log('Erro:', error.message);
            console.log('Dados recebidos:', data);
        }
    });

}).on('error', (error) => {
    console.log('❌ TESTE FALHOU: Erro de conexão');
    console.log('Erro:', error.message);
    console.log('\n💡 Dica: Certifique-se de que o servidor está rodando em http://localhost:3000');
    console.log('   Execute: cd webstock_backend && node server.js');
});
