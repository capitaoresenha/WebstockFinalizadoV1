const express = require('express');
const bcrypt = require('bcrypt');
const { pool, testConnection } = require('./db'); // Importa a conexão com o banco de dados

const app = express();
const PORT = 3000;
const saltRounds = 10; // Fator de segurança para o bcrypt

// Middleware para processar JSON no corpo das requisições
app.use(express.json());

// Middleware de CORS (necessário para que o frontend em HTML/JS possa se comunicar)
app.use((req, res, next) => {
    // Em produção, substitua '*' pelo domínio do seu frontend (ex: 'http://localhost:8080')
    res.setHeader('Access-Control-Allow-Origin', '*'); 
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    next();
});

// Testa a conexão com o banco de dados ao iniciar o servidor
testConnection();

// ==================== ROTAS DE AUTENTICAÇÃO ====================

// Rota de Login de Usuário (atualizada com role)
app.post('/api/login', async (req, res) => {
    const { email, senha } = req.body;

    if (!email || !senha) {
        return res.status(400).json({ erro: 'Email e senha são obrigatórios.' });
    }

    try {
        // 1. Buscar o usuário pelo email incluindo role
        const [rows] = await pool.execute(
            'SELECT id, senha_hash, nome, role FROM usuarios WHERE email = ? AND ativo = TRUE',
            [email]
        );

        if (rows.length === 0) {
            return res.status(401).json({ erro: 'Email ou senha inválidos.' });
        }

        const usuario = rows[0];

        // 2. Comparar a senha fornecida com o hash armazenado
        const match = await bcrypt.compare(senha, usuario.senha_hash);

        if (match) {
            // 3. Senha correta, login bem-sucedido
            res.status(200).json({ 
                mensagem: 'Login realizado com sucesso!', 
                usuarioId: usuario.id,
                nome: usuario.nome,
                role: usuario.role
            });
        } else {
            return res.status(401).json({ erro: 'Email ou senha inválidos.' });
        }

    } catch (error) {
        console.error('Erro no login:', error);
        res.status(500).json({ erro: 'Erro interno do servidor ao tentar login.' });
    }
});

// Rota de Cadastro de Usuário (atualizada com role e nome)
app.post('/api/cadastro', async (req, res) => {
    const { email, senha, nome, role } = req.body;

    // Validação básica
    if (!email || !senha) {
        return res.status(400).json({ erro: 'Email e senha são obrigatórios.' });
    }

    try {
        // 1. Gerar o hash da senha
        const senhaHash = await bcrypt.hash(senha, saltRounds);

        // 2. Inserir o novo usuário no banco de dados
        const roleUsuario = role || 'estudante'; // Padrão: estudante
        const [result] = await pool.execute(
            'INSERT INTO usuarios (email, senha_hash, nome, role) VALUES (?, ?, ?, ?)',
            [email, senhaHash, nome || null, roleUsuario]
        );

        // 3. Responder com sucesso
        res.status(201).json({ 
            mensagem: 'Usuário cadastrado com sucesso!', 
            usuarioId: result.insertId,
            role: roleUsuario
        });

    } catch (error) {
        console.error('Erro no cadastro:', error);

        // Tratar erro de email duplicado
        if (error.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({ erro: 'Este email já está cadastrado.' });
        }

        res.status(500).json({ erro: 'Erro interno do servidor ao cadastrar usuário.' });
    }
});

// ==================== ROTAS DE CATEGORIAS/ESTOQUE ====================

// Rota para buscar itens de estoque (Categorias)
app.get('/api/categorias', async (req, res) => {
    try {
        const [rows] = await pool.execute(
            'SELECT id, nome, status, quantidade, DATE_FORMAT(data_registro, "%d/%m/%y") as data_registro, materia, observacao FROM itens_estoque ORDER BY id ASC'
        );

        res.status(200).json({ 
            sucesso: true,
            itens: rows 
        });

    } catch (error) {
        console.error('Erro ao buscar categorias:', error);
        res.status(500).json({ erro: 'Erro interno do servidor ao buscar categorias.' });
    }
});

// Rota para adicionar item de estoque (apenas administrador)
app.post('/api/categorias', async (req, res) => {
    const { nome, status, quantidade, data_registro, materia, observacao, usuarioId } = req.body;

    if (!nome || !quantidade) {
        return res.status(400).json({ erro: 'Nome e quantidade são obrigatórios.' });
    }

    try {
        // Verificar se o usuário é administrador
        const [userRows] = await pool.execute(
            'SELECT role FROM usuarios WHERE id = ?',
            [usuarioId]
        );

        if (userRows.length === 0 || userRows[0].role !== 'administrador') {
            return res.status(403).json({ erro: 'Acesso negado. Apenas administradores podem adicionar itens.' });
        }

        // Inserir novo item
        const [result] = await pool.execute(
            'INSERT INTO itens_estoque (nome, status, quantidade, data_registro, materia, observacao, usuario_id) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [nome, status || 'Ativo', quantidade, data_registro || null, materia || null, observacao || null, usuarioId]
        );

        res.status(201).json({ 
            mensagem: 'Item adicionado com sucesso!', 
            itemId: result.insertId 
        });

    } catch (error) {
        console.error('Erro ao adicionar item:', error);
        res.status(500).json({ erro: 'Erro interno do servidor ao adicionar item.' });
    }
});

// Rota para atualizar item de estoque (apenas administrador)
app.put('/api/categorias/:id', async (req, res) => {
    const itemId = req.params.id;
    const { nome, status, quantidade, data_registro, materia, observacao, usuarioId } = req.body;

    try {
        // Verificar se o usuário é administrador
        const [userRows] = await pool.execute(
            'SELECT role FROM usuarios WHERE id = ?',
            [usuarioId]
        );

        if (userRows.length === 0 || userRows[0].role !== 'administrador') {
            return res.status(403).json({ erro: 'Acesso negado. Apenas administradores podem editar itens.' });
        }

        // Atualizar item
        const [result] = await pool.execute(
            'UPDATE itens_estoque SET nome = ?, status = ?, quantidade = ?, data_registro = ?, materia = ?, observacao = ?, usuario_id = ? WHERE id = ?',
            [nome, status, quantidade, data_registro, materia, observacao, usuarioId, itemId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ erro: 'Item não encontrado.' });
        }

        res.status(200).json({ mensagem: 'Item atualizado com sucesso!' });

    } catch (error) {
        console.error('Erro ao atualizar item:', error);
        res.status(500).json({ erro: 'Erro interno do servidor ao atualizar item.' });
    }
});

// Rota para deletar item de estoque (apenas administrador)
app.delete('/api/categorias/:id', async (req, res) => {
    const itemId = req.params.id;
    const { usuarioId } = req.body;

    try {
        // Verificar se o usuário é administrador
        const [userRows] = await pool.execute(
            'SELECT role FROM usuarios WHERE id = ?',
            [usuarioId]
        );

        if (userRows.length === 0 || userRows[0].role !== 'administrador') {
            return res.status(403).json({ erro: 'Acesso negado. Apenas administradores podem deletar itens.' });
        }

        // Deletar item
        const [result] = await pool.execute(
            'DELETE FROM itens_estoque WHERE id = ?',
            [itemId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ erro: 'Item não encontrado.' });
        }

        res.status(200).json({ mensagem: 'Item deletado com sucesso!' });

    } catch (error) {
        console.error('Erro ao deletar item:', error);
        res.status(500).json({ erro: 'Erro interno do servidor ao deletar item.' });
    }
});

// ==================== ROTAS DE FEEDBACKS ====================

// Rota para criar feedback (estudantes e administradores)
app.post('/api/feedbacks', async (req, res) => {
    const { usuarioId, titulo, mensagem, categoria } = req.body;

    if (!usuarioId || !titulo || !mensagem) {
        return res.status(400).json({ erro: 'Usuário, título e mensagem são obrigatórios.' });
    }

    try {
        // Inserir feedback
        const [result] = await pool.execute(
            'INSERT INTO feedbacks (usuario_id, titulo, mensagem, categoria) VALUES (?, ?, ?, ?)',
            [usuarioId, titulo, mensagem, categoria || 'outro']
        );

        const feedbackId = result.insertId;

        // Buscar todos os administradores para notificar
        const [admins] = await pool.execute(
            'SELECT id, nome FROM usuarios WHERE role = "administrador" AND ativo = TRUE'
        );

        // Buscar nome do usuário que enviou o feedback
        const [userRows] = await pool.execute(
            'SELECT nome FROM usuarios WHERE id = ?',
            [usuarioId]
        );

        const nomeUsuario = userRows[0]?.nome || 'Usuário';

        // Criar notificação para cada administrador
        for (const admin of admins) {
            await pool.execute(
                'INSERT INTO notificacoes (usuario_destinatario_id, tipo, titulo, mensagem, referencia_id) VALUES (?, ?, ?, ?, ?)',
                [admin.id, 'feedback', 'Novo feedback recebido', `${nomeUsuario} enviou: ${titulo}`, feedbackId]
            );
        }

        res.status(201).json({ 
            sucesso: true, // Adicionando a chave 'sucesso' para o frontend
            mensagem: 'Feedback enviado com sucesso!', 
            feedbackId: feedbackId 
        });

    } catch (error) {
        console.error('Erro ao criar feedback:', error);
        res.status(500).json({ erro: 'Erro interno do servidor ao criar feedback.' });
    }
});

// Rota para buscar feedbacks (apenas administradores veem todos, estudantes veem apenas os seus)
app.get('/api/feedbacks', async (req, res) => {
    const { usuarioId } = req.query;

    if (!usuarioId) {
        return res.status(400).json({ erro: 'ID do usuário é obrigatório.' });
    }

    try {
        // Verificar role do usuário
        const [userRows] = await pool.execute(
            'SELECT role FROM usuarios WHERE id = ?',
            [usuarioId]
        );

        if (userRows.length === 0) {
            return res.status(404).json({ erro: 'Usuário não encontrado.' });
        }

        const role = userRows[0].role;
        let query;
        let params;

        if (role === 'administrador') {
            // Administradores veem todos os feedbacks
            query = `
                SELECT f.id, f.titulo, f.mensagem, f.categoria, f.status, 
                       DATE_FORMAT(f.data_criacao, "%d/%m/%Y %H:%i") as data_criacao,
                       u.nome as nome_usuario, u.email as email_usuario
                FROM feedbacks f
                LEFT JOIN usuarios u ON f.usuario_id = u.id
                WHERE f.arquivado = FALSE
                ORDER BY f.data_criacao DESC
            `;
            params = [];
        } else {
            // Estudantes veem apenas seus próprios feedbacks
            query = `
                SELECT id, titulo, mensagem, categoria, status, 
                       DATE_FORMAT(data_criacao, "%d/%m/%Y %H:%i") as data_criacao
                FROM feedbacks
                WHERE usuario_id = ? AND arquivado = FALSE
                ORDER BY data_criacao DESC
            `;
            params = [usuarioId];
        }

        const [rows] = await pool.execute(query, params);

        res.status(200).json({ 
            sucesso: true,
            feedbacks: rows 
        });

    } catch (error) {
        console.error('Erro ao buscar feedbacks:', error);
        // Retorna o erro de forma clara para o frontend
        res.status(500).json({ sucesso: false, erro: 'Erro interno do servidor ao buscar feedbacks. Detalhe: ' + error.message });
    }
});

// Rota para atualizar status do feedback (apenas administrador)
app.put('/api/feedbacks/:id', async (req, res) => {
    const feedbackId = req.params.id;
    const { usuarioId, status } = req.body;

    try {
        // Verificar se o usuário é administrador
        const [userRows] = await pool.execute(
            'SELECT role FROM usuarios WHERE id = ?',
            [usuarioId]
        );

        if (userRows.length === 0 || userRows[0].role !== 'administrador') {
            return res.status(403).json({ erro: 'Acesso negado. Apenas administradores podem atualizar feedbacks.' });
        }

        // Atualizar status e arquivar se for 'resolvido'
        const dataLeitura = status === 'lido' || status === 'resolvido' ? new Date() : null;
        const arquivado = status === 'resolvido' ? true : false;
        
        const [result] = await pool.execute(
            'UPDATE feedbacks SET status = ?, data_leitura = ?, arquivado = ? WHERE id = ?',
            [status, dataLeitura, arquivado, feedbackId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ erro: 'Feedback não encontrado.' });
        }

        // 1. Buscar o ID do usuário que enviou o feedback
        const [feedbackRows] = await pool.execute(
            'SELECT usuario_id, titulo FROM feedbacks WHERE id = ?',
            [feedbackId]
        );

        if (feedbackRows.length > 0) {
            const { usuario_id, titulo } = feedbackRows[0];
            
            // 2. Criar notificação para o usuário (estudante)
            let tituloNotificacao = `Status do Feedback Alterado: ${status}`;
            let mensagemNotificacao = `Seu feedback "${titulo}" foi marcado como ${status}.`;

            if (status === 'resolvido') {
                tituloNotificacao = 'Feedback Resolvido!';
                mensagemNotificacao = `Seu feedback "${titulo}" foi resolvido!`;
            }

            await pool.execute(
                'INSERT INTO notificacoes (usuario_destinatario_id, tipo, titulo, mensagem, referencia_id) VALUES (?, ?, ?, ?, ?)',
                [usuario_id, 'feedback', tituloNotificacao, mensagemNotificacao, feedbackId]
            );
        }

        res.status(200).json({ sucesso: true, mensagem: 'Feedback atualizado com sucesso!' });

    } catch (error) {
        console.error('Erro ao atualizar feedback:', error);
        res.status(500).json({ erro: 'Erro interno do servidor ao atualizar feedback.' });
    }
});

// Rota para deletar feedback (administrador ou próprio usuário)
app.delete('/api/feedbacks/:id', async (req, res) => {
    const feedbackId = req.params.id;
    const { usuarioId } = req.body; // ID do usuário que está tentando deletar

    if (!usuarioId) {
        return res.status(400).json({ erro: 'ID do usuário é obrigatório.' });
    }

    try {
        // 1. Verificar role do usuário
        const [userRows] = await pool.execute(
            'SELECT role FROM usuarios WHERE id = ?',
            [usuarioId]
        );

        if (userRows.length === 0) {
            return res.status(404).json({ erro: 'Usuário não encontrado.' });
        }

        const role = userRows[0].role;

        // 2. Se não for administrador, verificar se é o dono do feedback
        if (role !== 'administrador') {
            const [feedbackRows] = await pool.execute(
                'SELECT usuario_id FROM feedbacks WHERE id = ?',
                [feedbackId]
            );

            if (feedbackRows.length === 0) {
                return res.status(404).json({ erro: 'Feedback não encontrado.' });
            }

            if (feedbackRows[0].usuario_id !== parseInt(usuarioId)) {
                return res.status(403).json({ erro: 'Acesso negado. Você só pode deletar seus próprios feedbacks.' });
            }
        }

        // 3. Deletar o feedback
        const [result] = await pool.execute(
            'DELETE FROM feedbacks WHERE id = ?',
            [feedbackId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ erro: 'Feedback não encontrado.' });
        }

        res.status(200).json({ sucesso: true, mensagem: 'Feedback deletado com sucesso!' });

    } catch (error) {
        console.error('Erro ao deletar feedback:', error);
        res.status(500).json({ erro: 'Erro interno do servidor ao deletar feedback.' });
    }
});

// ==================== ROTAS DE NOTIFICAÇÕES ====================

// Rota para buscar notificações do usuário
app.get('/api/notificacoes', async (req, res) => {
    const { usuarioId } = req.query;

    if (!usuarioId) {
        return res.status(400).json({ erro: 'ID do usuário é obrigatório.' });
    }

    try {
        const [rows] = await pool.execute(
            `SELECT id, tipo, titulo, mensagem, lida, referencia_id,
                    DATE_FORMAT(data_criacao, "%d/%m/%Y %H:%i") as data_criacao
             FROM notificacoes
             WHERE usuario_destinatario_id = ?
             ORDER BY data_criacao DESC
             LIMIT 50`,
            [usuarioId]
        );

        res.status(200).json({ 
            sucesso: true,
            notificacoes: rows 
        });

    } catch (error) {
        console.error('Erro ao buscar notificações:', error);
        res.status(500).json({ erro: 'Erro interno do servidor ao buscar notificações.' });
    }
});

// Rota para contar notificações não lidas
app.get('/api/notificacoes/count', async (req, res) => {
    const { usuarioId } = req.query;

    if (!usuarioId) {
        return res.status(400).json({ erro: 'ID do usuário é obrigatório.' });
    }

    try {
        const [rows] = await pool.execute(
            'SELECT COUNT(*) as total FROM notificacoes WHERE usuario_destinatario_id = ? AND lida = FALSE',
            [usuarioId]
        );

        res.status(200).json({ 
            sucesso: true,
            total: rows[0].total 
        });

    } catch (error) {
        console.error('Erro ao contar notificações:', error);
        res.status(500).json({ erro: 'Erro interno do servidor ao contar notificações.' });
    }
});

// Rota para marcar notificação como lida
app.put('/api/notificacoes/:id/marcar-lida', async (req, res) => {
    const notificacaoId = req.params.id;
    const { usuarioId } = req.body;

    try {
        const [result] = await pool.execute(
            'UPDATE notificacoes SET lida = TRUE WHERE id = ? AND usuario_destinatario_id = ?',
            [notificacaoId, usuarioId]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ erro: 'Notificação não encontrada.' });
        }

        res.status(200).json({ mensagem: 'Notificação marcada como lida!' });

    } catch (error) {
        console.error('Erro ao marcar notificação:', error);
        res.status(500).json({ erro: 'Erro interno do servidor ao marcar notificação.' });
    }
});

// Rota para marcar todas as notificações como lidas
app.put('/api/notificacoes/marcar-todas-lidas', async (req, res) => {
    const { usuarioId } = req.body;

    if (!usuarioId) {
        return res.status(400).json({ erro: 'ID do usuário é obrigatório.' });
    }

    try {
        await pool.execute(
            'UPDATE notificacoes SET lida = TRUE WHERE usuario_destinatario_id = ? AND lida = FALSE',
            [usuarioId]
        );

        res.status(200).json({ mensagem: 'Todas as notificações foram marcadas como lidas!' });

    } catch (error) {
        console.error('Erro ao marcar todas as notificações:', error);
        res.status(500).json({ erro: 'Erro interno do servidor ao marcar notificações.' });
    }
});

// Inicia o servidor
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});