// Sistema de Notificações - WebStock
// Versão 1.0 - Integrado com feedbacks e contador visual

const API_URL = 'http://localhost:3000/api';

// Recuperar dados do usuário logado
function getUsuarioLogado() {
    const usuario = localStorage.getItem('usuarioLogado');
    return usuario ? JSON.parse(usuario) : null;
}

/**
 * Alternar visibilidade da caixa de notificações
 */
function toggleNotifications() {
    const box = document.getElementById('notification-box');
    
    if (box.classList.contains('show')) {
        box.classList.remove('show');
    } else {
        box.classList.add('show');
        carregarNotificacoes();
    }
}

/**
 * Carregar notificações do usuário
 */
async function carregarNotificacoes() {
    const usuario = getUsuarioLogado();
    
    if (!usuario) {
        document.getElementById('notification-list').innerHTML = `
            <p style="text-align: center; padding: 20px;">Você precisa estar logado.</p>
        `;
        return;
    }

    try {
        const response = await fetch(`${API_URL}/notificacoes?usuarioId=${usuario.usuarioId}`);
        
        if (!response.ok) {
            throw new Error(`Erro HTTP: ${response.status}`);
        }

        const data = await response.json();

        if (data.sucesso && data.notificacoes) {
            renderizarNotificacoes(data.notificacoes);
        } else {
            throw new Error('Formato de resposta inválido');
        }

    } catch (error) {
        console.error('Erro ao carregar notificações:', error);
        document.getElementById('notification-list').innerHTML = `
            <p style="text-align: center; padding: 20px; color: #f44336;">
                Erro ao carregar notificações.
            </p>
        `;
    }
}

/**
 * Renderizar notificações na caixa
 */
function renderizarNotificacoes(notificacoes) {
    const container = document.getElementById('notification-list');

    if (!notificacoes || notificacoes.length === 0) {
        container.innerHTML = `
            <p style="text-align: center; padding: 20px; color: #666;">
                Não há notificações.
            </p>
        `;
        return;
    }

    container.innerHTML = '';

    notificacoes.forEach(notif => {
        const item = document.createElement('div');
        item.className = 'notification-item' + (notif.lida ? '' : ' unread');
        item.onclick = () => marcarComoLida(notif.id);

        const icone = obterIconeNotificacao(notif.tipo);

        item.innerHTML = `
            <div class="notification-tipo">${icone} ${notif.tipo}</div>
            <div class="notification-titulo">${notif.titulo}</div>
            <div class="notification-mensagem">${notif.mensagem}</div>
            <div class="notification-data">${notif.data_criacao}</div>
        `;

        container.appendChild(item);
    });
}

/**
 * Obter ícone baseado no tipo de notificação
 */
function obterIconeNotificacao(tipo) {
    const icones = {
        'feedback': '💬',
        'sistema': '⚙️',
        'estoque': '📦'
    };
    return icones[tipo] || '🔔';
}

/**
 * Marcar notificação como lida
 */
async function marcarComoLida(notificacaoId) {
    const usuario = getUsuarioLogado();
    
    if (!usuario) return;

    try {
        const response = await fetch(`${API_URL}/notificacoes/${notificacaoId}/marcar-lida`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                usuarioId: usuario.usuarioId
            })
        });

        if (response.ok) {
            // Recarregar notificações e atualizar contador
            carregarNotificacoes();
            atualizarContadorNotificacoes();
        }

    } catch (error) {
        console.error('Erro ao marcar notificação como lida:', error);
    }
}

/**
 * Marcar todas as notificações como lidas
 */
async function marcarTodasLidas() {
    const usuario = getUsuarioLogado();
    
    if (!usuario) return;

    try {
        const response = await fetch(`${API_URL}/notificacoes/marcar-todas-lidas`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                usuarioId: usuario.usuarioId
            })
        });

        if (response.ok) {
            // Recarregar notificações e atualizar contador
            carregarNotificacoes();
            atualizarContadorNotificacoes();
        }

    } catch (error) {
        console.error('Erro ao marcar todas as notificações:', error);
    }
}

/**
 * Atualizar contador de notificações não lidas
 */
async function atualizarContadorNotificacoes() {
    const usuario = getUsuarioLogado();
    
    if (!usuario) {
        const badge = document.getElementById('notif-badge');
        if (badge) {
            badge.style.display = 'none';
        }
        return;
    }

    try {
        const response = await fetch(`${API_URL}/notificacoes/count?usuarioId=${usuario.usuarioId}`);
        
        if (!response.ok) {
            throw new Error(`Erro HTTP: ${response.status}`);
        }

        const data = await response.json();

        if (data.sucesso) {
            const badge = document.getElementById('notif-badge');
            
            if (badge) {
                if (data.total > 0) {
                    badge.textContent = data.total > 99 ? '99+' : data.total;
                    badge.style.display = 'inline-block';
                } else {
                    badge.style.display = 'none';
                }
            }
        }

    } catch (error) {
        console.error('Erro ao atualizar contador de notificações:', error);
    }
}

/**
 * Fechar notificações ao clicar fora
 */
document.addEventListener('click', function(event) {
    const box = document.getElementById('notification-box');
    const button = document.querySelector('.notif-icon');
    
    if (box && button && !box.contains(event.target) && !button.contains(event.target)) {
        box.classList.remove('show');
    }
});

// Inicialização e atualização periódica
document.addEventListener('DOMContentLoaded', () => {
    // Atualizar contador ao carregar a página
    atualizarContadorNotificacoes();

    // Atualizar contador a cada 30 segundos
    setInterval(() => {
        atualizarContadorNotificacoes();
    }, 30000);
});
