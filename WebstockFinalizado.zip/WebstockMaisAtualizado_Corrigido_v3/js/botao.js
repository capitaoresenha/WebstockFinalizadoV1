
document.addEventListener('DOMContentLoaded', () => {
    const botao = document.getElementById('botao'); // Assumindo que o ID do botão é 'botao'
    const info = document.getElementById('info');

    if (botao && info) {
        botao.addEventListener('click', function () {
            if (info.style.display === 'none') {
                info.style.display = 'block';
                botao.textContent = '^';
            } else {
                info.style.display = 'none';
                botao.textContent = 'v';
            }
        });
    }

    const MeuBotao = document.getElementById('MeuBotao');
    const info2 = document.getElementById('info2');

    if (MeuBotao && info2) {
        MeuBotao.addEventListener('click', function () {
            if (info2.style.display === 'none') {
                info2.style.display = 'block';
                MeuBotao.textContent = '^';
            } else {
                info2.style.display = 'none';
                MeuBotao.textContent = 'v';
            }
        });
    }
});