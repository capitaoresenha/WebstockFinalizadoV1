function toggleNotifications() {
    const box = document.getElementById('notification-box');
    box.classList.toggle('show');
}
