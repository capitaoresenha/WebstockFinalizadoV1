// Sistema de Conexão SQL Integrado para Categorias com Permissões
// Versão 2.0 - Inclui edição para administradores

// Recuperar dados do usuário logado do localStorage
function getUsuarioLogado() {
    const usuario = localStorage.getItem('usuarioLogado');
    return usuario ? JSON.parse(usuario) : null;
}

// Verificar se o usuário é administrador
function isAdministrador() {
    const usuario = getUsuarioLogado();
    return usuario && usuario.role === 'administrador';
}

/**
 * Carrega os itens de estoque do banco de dados e atualiza a tabela
 */
async function carregarCategorias() {
    try {
        // Exibe indicador de carregamento
        const tbody = document.querySelector('.funcategorias tbody');
        tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 20px;">Carregando dados...</td></tr>';

        // Faz requisição para o backend
        const response = await fetch(`${API_URL}/categorias`);
        
        if (!response.ok) {
            throw new Error(`Erro HTTP: ${response.status}`);
        }

        const data = await response.json();

        if (data.sucesso && data.itens) {
            renderizarTabela(data.itens);
        } else {
            throw new Error('Formato de resposta inválido');
        }

    } catch (error) {
        console.error('Erro ao carregar categorias:', error);
        
        const tbody = document.querySelector('.funcategorias tbody');
        tbody.innerHTML = `
            <tr>
                <td colspan="8" style="text-align: center; padding: 20px; color: #ff4444;">
                    <strong>Erro ao carregar dados do banco de dados.</strong><br>
                    <small>Verifique se o servidor está rodando em ${API_URL}</small><br>
                    <small style="color: #666;">Detalhes: ${error.message}</small>
                </td>
            </tr>
        `;
    }
}

/**
 * Renderiza os itens na tabela HTML
 * @param {Array} itens - Array de itens do estoque
 */
function renderizarTabela(itens) {
    const tbody = document.querySelector('.funcategorias tbody');
    const isAdmin = isAdministrador();
    
    if (!itens || itens.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; padding: 20px;">Nenhum item encontrado no estoque.</td></tr>';
        return;
    }

    // Limpa a tabela
    tbody.innerHTML = '';

    // Adiciona cada item como uma linha
    itens.forEach(item => {
        const tr = document.createElement('tr');
        
        // Determina a classe CSS do status
        const statusClass = item.status === 'Ativo' ? 'active' : 'inactive';
        
        // Formata os campos vazios
        const materia = item.materia && item.materia !== '-' ? item.materia : '-';
        const observacao = item.observacao && item.observacao !== '-' ? item.observacao : '-';
        
        // Adiciona coluna de ações apenas para administradores
        const acoesHTML = isAdmin ? `
            <td>
                <button class="btn-editar" onclick="editarItem(${item.id})" title="Editar">
                    ✏️
                </button>
                <button class="btn-deletar" onclick="deletarItem(${item.id})" title="Deletar">
                    🗑️
                </button>
            </td>
        ` : '';
        
        tr.innerHTML = `
            <td><span class="status ${statusClass}">${item.status}</span></td>
            <td>${item.nome}</td>
            <td>${String(item.id).padStart(2, '0')}</td>
            <td>${item.data_registro || '-'}</td>
            <td>${item.quantidade}</td>
            <td>${materia}</td>
            <td>${observacao}</td>
            ${acoesHTML}
        `;
        
        tbody.appendChild(tr);
    });
}

/**
 * Editar item (apenas administradores)
 */
async function editarItem(itemId) {
    const usuario = getUsuarioLogado();
    if (!usuario || usuario.role !== 'administrador') {
        alert('Acesso negado. Apenas administradores podem editar itens.');
        return;
    }

    try {
        // Buscar dados atuais do item
        const response = await fetch(`${API_URL}/categorias`);
        const data = await response.json();
        const item = data.itens.find(i => i.id === itemId);

        if (!item) {
            alert('Item não encontrado.');
            return;
        }

        // Criar formulário de edição
        const nome = prompt('Nome do item:', item.nome);
        if (nome === null) return; // Cancelado

        const status = confirm('O item está ativo?') ? 'Ativo' : 'Inativo';
        
        const quantidadeStr = prompt('Quantidade:', item.quantidade);
        if (quantidadeStr === null) return;
        const quantidade = parseInt(quantidadeStr);

        const dataStr = prompt('Data de registro (DD/MM/AA):', item.data_registro);
        if (dataStr === null) return;
        
        // Converter data de DD/MM/AA para YYYY-MM-DD
        let dataRegistro = null;
        if (dataStr && dataStr !== '-') {
            const partes = dataStr.split('/');
            if (partes.length === 3) {
                const ano = partes[2].length === 2 ? '20' + partes[2] : partes[2];
                dataRegistro = `${ano}-${partes[1].padStart(2, '0')}-${partes[0].padStart(2, '0')}`;
            }
        }

        const materia = prompt('Matéria:', item.materia === '-' ? '' : item.materia);
        if (materia === null) return;

        const observacao = prompt('Observação:', item.observacao === '-' ? '' : item.observacao);
        if (observacao === null) return;

        // Enviar atualização
        const updateResponse = await fetch(`${API_URL}/categorias/${itemId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nome,
                status,
                quantidade,
                data_registro: dataRegistro,
                materia: materia || null,
                observacao: observacao || null,
                usuarioId: usuario.usuarioId
            })
        });

        const result = await updateResponse.json();

        if (updateResponse.ok) {
            alert('Item atualizado com sucesso!');
            carregarCategorias(); // Recarregar tabela
        } else {
            alert('Erro ao atualizar item: ' + result.erro);
        }

    } catch (error) {
        console.error('Erro ao editar item:', error);
        alert('Erro ao editar item. Verifique o console para mais detalhes.');
    }
}

/**
 * Deletar item (apenas administradores)
 */
async function deletarItem(itemId) {
    const usuario = getUsuarioLogado();
    if (!usuario || usuario.role !== 'administrador') {
        alert('Acesso negado. Apenas administradores podem deletar itens.');
        return;
    }

    if (!confirm('Tem certeza que deseja deletar este item?')) {
        return;
    }

    try {
        const response = await fetch(`${API_URL}/categorias/${itemId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                usuarioId: usuario.usuarioId
            })
        });

        const result = await response.json();

        if (response.ok) {
            alert('Item deletado com sucesso!');
            carregarCategorias(); // Recarregar tabela
        } else {
            alert('Erro ao deletar item: ' + result.erro);
        }

    } catch (error) {
        console.error('Erro ao deletar item:', error);
        alert('Erro ao deletar item. Verifique o console para mais detalhes.');
    }
}

/**
 * Adicionar novo item (apenas administradores)
 */
async function adicionarItem() {
    const usuario = getUsuarioLogado();
    if (!usuario || usuario.role !== 'administrador') {
        alert('Acesso negado. Apenas administradores podem adicionar itens.');
        return;
    }

    try {
        const nome = prompt('Nome do item:');
        if (!nome) return;

        const status = confirm('O item está ativo?') ? 'Ativo' : 'Inativo';
        
        const quantidadeStr = prompt('Quantidade:', '0');
        if (quantidadeStr === null) return;
        const quantidade = parseInt(quantidadeStr);

        const dataStr = prompt('Data de registro (DD/MM/AA):');
        let dataRegistro = null;
        if (dataStr) {
            const partes = dataStr.split('/');
            if (partes.length === 3) {
                const ano = partes[2].length === 2 ? '20' + partes[2] : partes[2];
                dataRegistro = `${ano}-${partes[1].padStart(2, '0')}-${partes[0].padStart(2, '0')}`;
            }
        }

        const materia = prompt('Matéria:');
        const observacao = prompt('Observação:');

        // Enviar novo item
        const response = await fetch(`${API_URL}/categorias`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nome,
                status,
                quantidade,
                data_registro: dataRegistro,
                materia: materia || null,
                observacao: observacao || null,
                usuarioId: usuario.usuarioId
            })
        });

        const result = await response.json();

        if (response.ok) {
            alert('Item adicionado com sucesso!');
            carregarCategorias(); // Recarregar tabela
        } else {
            alert('Erro ao adicionar item: ' + result.erro);
        }

    } catch (error) {
        console.error('Erro ao adicionar item:', error);
        alert('Erro ao adicionar item. Verifique o console para mais detalhes.');
    }
}

/**
 * Atualiza automaticamente os dados a cada intervalo
 * @param {number} intervalo - Intervalo em milissegundos (padrão: 30 segundos)
 */
function iniciarAtualizacaoAutomatica(intervalo = 30000) {
    setInterval(() => {
        carregarCategorias();
    }, intervalo);
}

/**
 * Adiciona cabeçalho da coluna de ações para administradores
 */
function ajustarCabecalhoTabela() {
    const isAdmin = isAdministrador();
    const thead = document.querySelector('.funcategorias thead tr');
    
    if (isAdmin && !document.querySelector('.th-acoes')) {
        const th = document.createElement('th');
        th.className = 'th-acoes';
        th.textContent = 'Ações';
        thead.appendChild(th);
    }
}

/**
 * Adiciona botão de adicionar item para administradores
 */
function adicionarBotaoAdicionar() {
    const isAdmin = isAdministrador();
    
    if (isAdmin) {
        const section = document.querySelector('.funcategorias');
        const botao = document.createElement('button');
        botao.textContent = '➕ Adicionar Item';
        botao.className = 'tmudo btn-adicionar';
        botao.style.marginTop = '20px';
        botao.onclick = adicionarItem;
        section.appendChild(botao);
    }
}

/**
 * Adiciona botão de recarregar
 */
function adicionarBotaoRecarregar() {
    const section = document.querySelector('.funcategorias');
    const botao = document.createElement('button');
    botao.textContent = '🔄 Recarregar Dados';
    botao.className = 'tmudo';
    botao.style.marginTop = '20px';
    botao.style.marginLeft = '10px';
    botao.onclick = carregarCategorias;
    section.appendChild(botao);
}

// Carrega os dados quando a página é carregada
document.addEventListener('DOMContentLoaded', () => {
    ajustarCabecalhoTabela();
    carregarCategorias();
    adicionarBotaoAdicionar();
    adicionarBotaoRecarregar();
    
    // Opcional: Ativa atualização automática a cada 30 segundos
    // iniciarAtualizacaoAutomatica(30000);
});
