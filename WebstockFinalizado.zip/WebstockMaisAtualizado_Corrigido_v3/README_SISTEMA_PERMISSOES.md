# WebStock - Sistema de Permissões e Feedbacks

## 📋 Novidades da Versão 2.0

Este documento descreve as novas funcionalidades implementadas no sistema WebStock, incluindo **sistema de permissões** (administrador/estudante) e **sistema de feedbacks integrado às notificações**.

---

## 🎯 Funcionalidades Implementadas

### 1. Sistema de Permissões (Roles)

O sistema agora distingue entre dois tipos de usuários:

#### **Administrador**
- Pode **visualizar**, **editar**, **adicionar** e **deletar** itens na página de categorias
- Recebe **notificações** quando estudantes enviam feedbacks
- Pode **visualizar todos os feedbacks** enviados por estudantes
- Pode **alterar o status** dos feedbacks (pendente → lido → resolvido)

#### **Estudante**
- Pode **apenas visualizar** os itens na página de categorias
- Pode **enviar feedbacks** para os administradores
- Pode **visualizar apenas seus próprios feedbacks**
- Recebe confirmação quando o feedback é enviado

---

### 2. Edição de Categorias (Apenas Administradores)

Na página **categorias.html**, administradores têm acesso a:

- **Botões de ação** em cada linha da tabela:
  - ✏️ **Editar**: Modificar informações do item
  - 🗑️ **Deletar**: Remover item do estoque

- **Botão "Adicionar Item"**: Criar novos itens de estoque

Estudantes veem apenas a tabela de visualização, sem botões de edição.

---

### 3. Sistema de Feedbacks

Nova página **feedbacks.html** com:

#### **Formulário de Envio** (Todos os usuários)
- Título do feedback
- Categoria (Sugestão, Problema, Dúvida, Outro)
- Mensagem detalhada

#### **Lista de Feedbacks**
- **Administradores** veem todos os feedbacks com:
  - Nome e email do estudante que enviou
  - Status atual (Pendente, Lido, Resolvido)
  - Botões para alterar status
  
- **Estudantes** veem apenas seus próprios feedbacks

---

### 4. Sistema de Notificações

Implementado em **todas as páginas** (home, categorias, feedbacks):

#### **Contador Visual**
- Badge vermelho no sino de notificações mostrando quantidade de notificações não lidas
- Atualização automática a cada 30 segundos

#### **Caixa de Notificações**
- Clique no sino para abrir/fechar
- Lista de notificações com:
  - Tipo (Feedback, Sistema, Estoque)
  - Título e mensagem
  - Data e hora
  - Indicador visual para não lidas (fundo amarelo)

#### **Integração com Feedbacks**
- Quando um estudante envia feedback, **todos os administradores** recebem uma notificação automaticamente
- Notificação inclui nome do estudante e título do feedback

---

## 🗄️ Alterações no Banco de Dados

### Novo Script SQL: `webstock_db_script_v2.sql`

#### Tabela `usuarios` (atualizada)
```sql
- role ENUM('administrador', 'estudante') DEFAULT 'estudante'
```

#### Nova Tabela `feedbacks`
```sql
- id (PRIMARY KEY)
- usuario_id (FOREIGN KEY)
- titulo
- mensagem
- categoria (sugestao, problema, duvida, outro)
- status (pendente, lido, resolvido)
- data_criacao
- data_leitura
```

#### Nova Tabela `notificacoes`
```sql
- id (PRIMARY KEY)
- usuario_destinatario_id (FOREIGN KEY)
- tipo (feedback, sistema, estoque)
- titulo
- mensagem
- lida (BOOLEAN)
- referencia_id (ID do feedback relacionado)
- data_criacao
```

---

## 🚀 Instruções de Instalação

### 1. Atualizar o Banco de Dados

Execute o novo script SQL:

```bash
mysql -u seu_usuario -p webstock_db < webstock_db_script_v2.sql
```

**Importante**: Este script cria as novas tabelas e adiciona a coluna `role` à tabela de usuários.

### 2. Instalar Dependências do Backend

Navegue até a pasta do backend:

```bash
cd webstock_backend
npm install
```

As dependências já incluem:
- `express`
- `bcrypt`
- `mysql2`

### 3. Configurar Conexão com Banco de Dados

Edite o arquivo `webstock_backend/db.js` com suas credenciais:

```javascript
const pool = mysql.createPool({
    host: 'localhost',
    user: 'seu_usuario',
    password: 'sua_senha',
    database: 'webstock_db',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});
```

### 4. Iniciar o Servidor

```bash
cd webstock_backend
node server.js
```

O servidor estará rodando em: `http://localhost:3000`

### 5. Abrir o Frontend

Abra o arquivo `html/index.html` em um navegador ou use um servidor local:

```bash
# Exemplo com Python
python3 -m http.server 8080
```

Acesse: `http://localhost:8080/html/index.html`

---

## 👥 Criando Usuários

### Criar Administrador

Para criar um usuário administrador, você pode:

1. **Cadastrar normalmente** pelo site
2. **Atualizar o role no banco de dados**:

```sql
UPDATE usuarios SET role = 'administrador' WHERE email = 'admin@exemplo.com';
```

### Criar Estudante

Basta cadastrar normalmente pelo site. O role padrão é `estudante`.

---

## 📝 Como Usar

### Para Administradores

1. **Login** com conta de administrador
2. **Categorias**: Edite, adicione ou delete itens de estoque
3. **Feedbacks**: Visualize feedbacks de estudantes e altere status
4. **Notificações**: Receba alertas quando novos feedbacks chegarem

### Para Estudantes

1. **Login** com conta de estudante
2. **Categorias**: Visualize o estoque (sem edição)
3. **Feedbacks**: Envie sugestões, problemas ou dúvidas
4. **Acompanhamento**: Veja o status dos seus feedbacks

---

## 🎨 Paleta de Cores Mantida

O sistema de feedbacks e notificações segue a mesma identidade visual:

- **Azul Principal**: `#4547B5`
- **Amarelo/Dourado**: `#FFB41F`
- **Branco**: `#F5F6FF`
- **Gradientes**: Mantidos em todas as novas interfaces

---

## 🔧 Arquivos Novos/Modificados

### Novos Arquivos
- `html/feedbacks.html` - Página de feedbacks
- `css/feedbacks.css` - Estilos da página de feedbacks
- `js/feedbacks.js` - Lógica de feedbacks
- `js/notificacoes.js` - Sistema de notificações
- `webstock_db_script_v2.sql` - Script SQL atualizado
- `README_SISTEMA_PERMISSOES.md` - Este documento

### Arquivos Modificados
- `webstock_backend/server.js` - Novas rotas e verificação de permissões
- `js/categorias.js` - Edição para administradores
- `js/confirmacao.js` - Salvar dados do usuário com role
- `css/categorias.css` - Estilos dos botões de ação
- `css/home.css` - Estilos de notificações
- `html/home.html` - Contador de notificações
- `html/categorias.html` - Contador de notificações e link para feedbacks

---

## 🔐 Segurança

- Todas as rotas de edição verificam o **role do usuário** no backend
- Senhas são armazenadas com **bcrypt hash**
- Validação de permissões em **frontend e backend**
- Proteção contra **SQL injection** usando prepared statements

---

## 📊 Endpoints da API

### Autenticação
- `POST /api/login` - Login com role
- `POST /api/cadastro` - Cadastro com role opcional

### Categorias
- `GET /api/categorias` - Listar itens
- `POST /api/categorias` - Adicionar item (admin)
- `PUT /api/categorias/:id` - Editar item (admin)
- `DELETE /api/categorias/:id` - Deletar item (admin)

### Feedbacks
- `GET /api/feedbacks` - Listar feedbacks (filtrado por role)
- `POST /api/feedbacks` - Criar feedback
- `PUT /api/feedbacks/:id` - Atualizar status (admin)

### Notificações
- `GET /api/notificacoes` - Listar notificações
- `GET /api/notificacoes/count` - Contar não lidas
- `PUT /api/notificacoes/:id/marcar-lida` - Marcar como lida
- `PUT /api/notificacoes/marcar-todas-lidas` - Marcar todas como lidas

---

## 🐛 Solução de Problemas

### Erro: "Erro ao carregar dados do banco de dados"
- Verifique se o servidor backend está rodando
- Confirme as credenciais do banco de dados em `db.js`

### Botões de edição não aparecem
- Verifique se o usuário tem role `administrador` no banco de dados
- Confirme que o localStorage contém os dados do usuário após login

### Notificações não atualizam
- Verifique o console do navegador para erros
- Confirme que o endpoint `/api/notificacoes/count` está respondendo

---

## 📞 Suporte

Para dúvidas ou problemas, consulte a documentação original do WebStock ou entre em contato com a equipe de desenvolvimento.

---

**Versão**: 2.0  
**Data**: Novembro 2025  
**Desenvolvido para**: WebStock - Sistema de Gerenciamento de Estoque
