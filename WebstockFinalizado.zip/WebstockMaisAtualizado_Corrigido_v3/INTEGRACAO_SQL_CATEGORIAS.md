# Integração SQL - Sistema de Categorias

## 📋 Visão Geral

Este documento descreve a integração SQL implementada para a aba de **Categorias** do sistema WebStock. A integração permite que os dados exibidos no front-end sejam carregados dinamicamente do banco de dados MySQL, garantindo sincronização em tempo real.

---

## 🔧 Arquivos Modificados

### 1. **Backend - `webstock_backend/server.js`**

**Modificação:** Adicionado novo endpoint GET para buscar itens de estoque.

```javascript
// Rota para buscar itens de estoque (Categorias)
app.get('/api/categorias', async (req, res) => {
    try {
        // Buscar todos os itens de estoque
        const [rows] = await pool.execute(
            'SELECT id, nome, status, quantidade, DATE_FORMAT(data_registro, "%d/%m/%y") as data_registro, materia, observacao FROM itens_estoque ORDER BY id ASC'
        );

        res.status(200).json({ 
            sucesso: true,
            itens: rows 
        });

    } catch (error) {
        console.error('Erro ao buscar categorias:', error);
        res.status(500).json({ erro: 'Erro interno do servidor ao buscar categorias.' });
    }
});
```

**Localização:** Linha 68-85 do arquivo `server.js`

---

### 2. **Frontend - `js/categorias.js`** (NOVO)

**Descrição:** Arquivo JavaScript criado para gerenciar a comunicação entre o front-end e o banco de dados.

**Funcionalidades:**
- ✅ Carrega dados do banco via API REST
- ✅ Renderiza dinamicamente a tabela HTML
- ✅ Tratamento de erros com mensagens amigáveis
- ✅ Botão de recarregamento manual
- ✅ Suporte para atualização automática (opcional)

**Funções principais:**

| Função | Descrição |
|--------|-----------|
| `carregarCategorias()` | Busca os itens do banco e atualiza a tabela |
| `renderizarTabela(itens)` | Renderiza os itens na estrutura HTML |
| `iniciarAtualizacaoAutomatica(intervalo)` | Atualiza dados periodicamente (opcional) |
| `adicionarBotaoRecarregar()` | Adiciona botão de recarregamento manual |

---

### 3. **Frontend - `html/categorias.html`**

**Modificação:** Adicionado script de integração.

```html
<script src="../js/categorias.js"></script>
```

**Localização:** Linha 117 do arquivo `categorias.html`

---

## 🗄️ Estrutura do Banco de Dados

A integração utiliza a tabela `itens_estoque` do banco `webstock_db`:

```sql
CREATE TABLE IF NOT EXISTS itens_estoque (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    status ENUM('Ativo', 'Inativo') NOT NULL DEFAULT 'Ativo',
    quantidade INT NOT NULL DEFAULT 0,
    data_registro DATE,
    materia VARCHAR(100),
    observacao TEXT,
    usuario_id INT,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);
```

---

## 🚀 Como Usar

### 1. **Configurar o Banco de Dados**

Execute o script SQL fornecido:

```bash
mysql -u root -p < webstock_db_script.sql
```

### 2. **Configurar Credenciais**

Edite o arquivo `webstock_backend/db.js` com suas credenciais MySQL:

```javascript
const dbConfig = {
    host: 'localhost',
    user: 'seu_usuario',
    password: 'sua_senha',
    database: 'webstock_db'
};
```

### 3. **Iniciar o Servidor Backend**

```bash
cd webstock_backend
npm install
node server.js
```

O servidor estará rodando em: `http://localhost:3000`

### 4. **Abrir o Front-End**

Abra o arquivo `html/categorias.html` em um navegador ou use um servidor local:

```bash
# Opção 1: Usando Python
python3 -m http.server 8080

# Opção 2: Usando Node.js
npx http-server -p 8080
```

Acesse: `http://localhost:8080/html/categorias.html`

---

## 🔄 Fluxo de Dados

```
┌─────────────────┐
│  Banco de Dados │
│   (MySQL)       │
└────────┬────────┘
         │
         │ SQL Query
         │
┌────────▼────────┐
│   Backend       │
│  (Node.js +     │
│   Express)      │
└────────┬────────┘
         │
         │ REST API
         │ GET /api/categorias
         │
┌────────▼────────┐
│   Frontend      │
│  (HTML + JS)    │
│                 │
│  categorias.js  │
└─────────────────┘
```

---

## 📊 Exemplo de Resposta da API

**Endpoint:** `GET http://localhost:3000/api/categorias`

**Resposta de Sucesso (200):**

```json
{
  "sucesso": true,
  "itens": [
    {
      "id": 1,
      "nome": "Notebook",
      "status": "Ativo",
      "quantidade": 200,
      "data_registro": "07/06/25",
      "materia": "Curso Dev",
      "observacao": "Formatar a máquina 17"
    },
    {
      "id": 2,
      "nome": "Mouse",
      "status": "Inativo",
      "quantidade": 30,
      "data_registro": "30/04/25",
      "materia": "Curso Dev",
      "observacao": "Manutenção Necessária"
    }
  ]
}
```

**Resposta de Erro (500):**

```json
{
  "erro": "Erro interno do servidor ao buscar categorias."
}
```

---

## ⚙️ Funcionalidades Adicionais

### Atualização Automática

Para ativar a atualização automática dos dados a cada 30 segundos, descomente a linha no arquivo `categorias.js`:

```javascript
// Linha 103
iniciarAtualizacaoAutomatica(30000);
```

### Botão de Recarregamento

Um botão "🔄 Recarregar Dados" é adicionado automaticamente abaixo da tabela para atualização manual.

---

## 🛠️ Testando a Integração

### 1. **Testar o Endpoint**

```bash
curl http://localhost:3000/api/categorias
```

### 2. **Adicionar Novo Item no Banco**

```sql
INSERT INTO itens_estoque (nome, status, quantidade, data_registro, materia, observacao, usuario_id) 
VALUES ('Teclado', 'Ativo', 50, '2025-11-24', 'Curso Dev', 'Novo lote', 1);
```

### 3. **Recarregar a Página**

Clique no botão "🔄 Recarregar Dados" ou recarregue a página (F5) para ver o novo item.

---

## 🔒 Segurança

### Recomendações:

1. **CORS:** Em produção, substitua `'*'` pelo domínio específico do frontend
2. **Autenticação:** Implemente JWT para proteger endpoints
3. **Validação:** Adicione validação de entrada no backend
4. **SQL Injection:** Sempre use prepared statements (já implementado)
5. **HTTPS:** Use SSL/TLS em produção

---

## 🐛 Solução de Problemas

### Erro: "Erro ao carregar dados do banco de dados"

**Possíveis causas:**
- ✅ Servidor backend não está rodando
- ✅ Credenciais do banco incorretas
- ✅ Banco de dados não foi criado
- ✅ Problema de CORS

**Solução:**
1. Verifique se o servidor está rodando: `http://localhost:3000`
2. Verifique os logs do servidor no terminal
3. Teste o endpoint diretamente: `curl http://localhost:3000/api/categorias`

### Tabela Vazia

**Causa:** Não há dados no banco de dados

**Solução:**
```sql
USE webstock_db;
SELECT * FROM itens_estoque;
```

Se estiver vazio, execute novamente o script SQL com os dados de exemplo.

---

## 📝 Notas Importantes

- ⚠️ **Não foram alteradas outras partes do código** além das mencionadas neste documento
- ⚠️ Os dados estáticos do HTML foram mantidos como fallback caso o JavaScript não carregue
- ⚠️ O CSS (`categorias.css`) não foi modificado
- ⚠️ Outros arquivos JavaScript (`app.js`, `botao.js`) permanecem inalterados

---

## 📞 Suporte

Para dúvidas ou problemas com a integração:

1. Verifique os logs do servidor backend
2. Abra o Console do navegador (F12) para ver erros JavaScript
3. Consulte a documentação do MySQL e Node.js

---

**Versão:** 1.0  
**Data:** 24/11/2025  
**Autor:** Sistema de Integração WebStock
